CaseLab - web mô phỏng mở hòm CS2 (tiền ảo)

Cấu trúc:
  index.html   trang chính (HTML + CSS + JS trong một file)
  img/         42 ảnh skin (.webp)
  server.js    server Node.js tùy chọn, không cần cài thư viện

Cách 1 - Hosting tĩnh (cPanel, Nginx, Apache, GitHub Pages, Netlify, Vercel...):
  Upload index.html và thư mục img/ vào thư mục gốc web (public_html, www...). Không cần server.js.

Cách 2 - VPS có Node.js:
  node server.js            -> http://IP:3000
  PORT=80 node server.js    -> chạy cổng 80 (Linux cần quyền root)
  Chạy nền lâu dài: npm i -g pm2 && pm2 start server.js --name caselab

Lưu ý: số dư và kho đồ lưu trong localStorage trình duyệt của từng người chơi, không có cơ sở dữ liệu trên server.
